package com.example.magshimim.light_project;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class gameActivity extends AppCompatActivity implements View.OnClickListener {
    public ImageView light1, light2, light3, light4, light5, light6, light7, light8, light9;
    public TextView score;
    public Button btnYes, btnNo;
    Dialog d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        light1 = (ImageView)findViewById(R.id.light1);
        light2 = (ImageView)findViewById(R.id.light2);
        light3 = (ImageView)findViewById(R.id.light3);
        light4 = (ImageView)findViewById(R.id.light4);
        light5 = (ImageView)findViewById(R.id.light5);
        light6 = (ImageView)findViewById(R.id.light6);
        light7 = (ImageView)findViewById(R.id.light7);
        light8 = (ImageView)findViewById(R.id.light8);
        light9 = (ImageView)findViewById(R.id.light9);
        score = (TextView)findViewById(R.id.score);

        light1.setOnClickListener(this);
        light2.setOnClickListener(this);
        light3.setOnClickListener(this);
        light4.setOnClickListener(this);
        light5.setOnClickListener(this);
        light6.setOnClickListener(this);
        light7.setOnClickListener(this);
        light8.setOnClickListener(this);
        light9.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if(light1 == view)
        {

        }
        if(light2 == view)
        {

        }
        if(light3 == view)
        {

        }
        if(light4 == view)
        {

        }
        if(light5 == view)
        {

        }
        if(light6 == view)
        {

        }
        if(light7 == view)
        {

        }
        if(light8 == view)
        {

        }
        if(light9 == view)
        {

        }
    }

    @Override
    public void onBackPressed() {

        d = new Dialog(this);
        d.setContentView(R.layout.go_out_dialog);
        d.show();
        btnNo =(Button) d.findViewById(R.id.btnNo);
        btnYes =(Button) d.findViewById(R.id.btnYes);
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                finish();
            }
        });
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
    }
}
