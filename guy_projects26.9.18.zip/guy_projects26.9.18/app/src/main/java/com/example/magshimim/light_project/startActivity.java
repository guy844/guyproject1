package com.example.magshimim.light_project;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class startActivity extends AppCompatActivity {
    public TextView signUp, signIn, skip;
    public Button btnLogin;
    public EditText username, password;
    Dialog openLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        signUp = (TextView)findViewById(R.id.signUp);
        signIn = (TextView)findViewById(R.id.signIn);
        skip = (TextView)findViewById(R.id.skip);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent startActivity = new Intent(startActivity.this, registrationActivity.class);
                startActivity(startActivity);
            }
        });

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLogin = new Dialog(startActivity.this);
                openLogin.setContentView(R.layout.login_dialog);
                openLogin.show();
                btnLogin = (Button)openLogin.findViewById(R.id.btnLogin);
                username = (EditText)openLogin.findViewById(R.id.nameOfUser);
                password = (EditText)openLogin.findViewById(R.id.password);
                btnLogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //check username and password start
                        String checkUsername = username.getText().toString();
                        String checkPassword = password.getText().toString();
                        //check username and password end
                        if((checkUsername.matches("")) || (checkPassword.matches("")))
                        {
                            CharSequence text = "the username or the password you have entered does not match our records. please try again";
                            int duration = Toast.LENGTH_LONG;
                            Toast toast = Toast.makeText(getApplicationContext(), text, duration);
                            toast.show();
                        }
                        else
                        {
                            Intent startActivity = new Intent(startActivity.this, MainActivity.class);
                            String helloMsg = "               Hello " + checkUsername;
                            startActivity.putExtra("value", helloMsg);
                            startActivity(startActivity);
                        }
                    }
                });
            }
        });

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent startActivity = new Intent(startActivity.this, MainActivity.class);
                String guest = "               Hello Guest";
                startActivity.putExtra("value", guest);
                startActivity(startActivity);
            }
        });
    }
}
