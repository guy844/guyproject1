package com.example.magshimim.light_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public TextView tvGameclick, leadBoardclick, nameOfUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tvGameclick = (TextView)findViewById(R.id.tvGameclick);
        leadBoardclick = (TextView)findViewById(R.id.leadBoardclick);
        nameOfUser = (TextView)findViewById(R.id.nameOfUser);

        Intent intent = getIntent();
        String getDataFromIntent = intent.getStringExtra("value");
        nameOfUser.setText(getDataFromIntent);
        nameOfUser.setVisibility(View.VISIBLE);

        tvGameclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent MainActivity = new Intent(MainActivity.this, difficulty.class);
                startActivity(MainActivity);
            }
        });

        leadBoardclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent MainActivity = new Intent(MainActivity.this, Leadboard.class);
                startActivity(MainActivity);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();
        if(id == R.id.idProfile)
        {
            Intent MainActivity = new Intent(MainActivity.this, ProfileMenu.class);
            startActivity(MainActivity);
            return true;
        }
        if(id == R.id.idSetting)
        {
            Intent MainActivity = new Intent(MainActivity.this, SettingMenu.class);
            startActivity(MainActivity);
            return true;
        }
        return true;
    }
}
