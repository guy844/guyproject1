package com.example.magshimim.light_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class difficulty extends AppCompatActivity implements View.OnClickListener {
    public TextView easy, medium, hard, goBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_difficulty);
        easy = (TextView)findViewById(R.id.easy);
        medium = (TextView)findViewById(R.id.medium);
        hard = (TextView)findViewById(R.id.hard);
        goBack = (TextView)findViewById(R.id.goBack);
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                //Intent difficulty = new Intent(difficulty.this, MainActivity.class);
                //startActivity(difficulty);
            }
        });
        easy.setOnClickListener(this);
        medium.setOnClickListener(this);
        hard.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(easy == view)
        {
            String level = "1";
            Intent difficulty = new Intent(difficulty.this, gameActivity.class);
            difficulty.putExtra("value",level);
            startActivity(difficulty);
        }
        if(medium == view)
        {
            String level = "2";
            Intent difficulty = new Intent(difficulty.this, gameActivity.class);
            difficulty.putExtra("value",level);
            startActivity(difficulty);
        }
        if(hard == view)
        {
            String level = "3";
            Intent difficulty = new Intent(difficulty.this, gameActivity.class);
            difficulty.putExtra("value",level);
            startActivity(difficulty);
        }
    }
}
