package com.example.magshimim.light_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public TextView tvGameclick, leadBoardclick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvGameclick = (TextView)findViewById(R.id.tvGameclick);
        leadBoardclick = (TextView)findViewById(R.id.leadBoardclick);

        tvGameclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent MainActivity = new Intent(MainActivity.this, difficulty.class);
                startActivity(MainActivity);
            }
        });

        leadBoardclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent MainActivity = new Intent(MainActivity.this, Leadboard.class);
                startActivity(MainActivity);
            }
        });


    }
}
