package com.example.magshimim.light_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuthException;

public class registrationActivity extends AppCompatActivity {
    public TextView tv1, tv2;
    public EditText username, password;
    public Button register;
    private FirebaseAuthException firebaseAuthException;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        register = (Button)findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String checkUsername = username.getText().toString();
                String checkPassword = password.getText().toString();
                if((checkUsername.matches("")) || (checkPassword.matches("")))// check if the user insert username or password
                {
                    CharSequence text = "You did not enter a username or password!";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(getApplicationContext(), text, duration);
                    toast.show();
                }
                else
                {
                    CharSequence text = "Success!";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(getApplicationContext(), text, duration);
                    toast.show();
                    //upload to the DB
                    Intent registrationActivity = new Intent(registrationActivity.this, MainActivity.class);
                    startActivity(registrationActivity);
                }
            }
        });
    }
}
